package com.example.zootecbc;

import android.widget.EditText;

public class Animales {

    private  String area;
    private  String especie;
    private  String tamaño;
    private  String sexo;
    private  String edad;
    private  String color1;
    private  String color2;
    private  String raza;
    private  long fecha;

    public Animales(){

    }
    public Animales(String area, String especie, String tamaño, String sexo, String edad, String color1, String color2, String raza, long fecha){
        this.area = area;
        this.especie = especie;
        this.tamaño = tamaño;
        this.sexo = sexo;
        this.edad = edad;
        this.color1 = color1;
        this.color2 = color2;
        this.raza = raza;
        this.fecha = fecha;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getColor1() {
        return color1;
    }

    public void setColor1(String color1) {
        this.color1 = color1;
    }

    public String getColor2() {
        return color2;
    }

    public void setColor2(String color2) {
        this.color2 = color2;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public long getFecha() {
        return fecha;
    }

    public void setFecha(long fecha) {
        this.fecha = fecha;
    }
}
