package com.example.zootecbc;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class AnimalesAdapter extends FirestoreRecyclerAdapter <Animales, AnimalesAdapter.ViewHolder> {


    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public AnimalesAdapter(@NonNull FirestoreRecyclerOptions<Animales> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull Animales model) {
        holder.tvArea.setText(model.getArea());
        holder.tvEspecie.setText(model.getEspecie());
        holder.tvTamaño.setText(model.getTamaño());
        holder.tvSexo.setText(model.getSexo());
        holder.tvEdad.setText(model.getEdad());
        holder.tvColor1.setText(model.getColor1());
        holder.tvColor2.setText(model.getColor2());
        holder.tvRaza.setText(model.getRaza());
        holder.tvFecha.setText(String.valueOf(model.getFecha()));

    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_animales, parent, false);
        return new ViewHolder(view);
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tvArea;
        TextView tvEspecie;
        TextView tvTamaño;
        TextView tvSexo;
        TextView tvEdad;
        TextView tvColor1;
        TextView tvColor2;
        TextView tvRaza;
        TextView tvFecha;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvArea = itemView.findViewById(R.id.tvArea);
            tvEspecie = itemView.findViewById(R.id.tvEspecie);
            tvTamaño = itemView.findViewById(R.id.tvTamaño);
            tvSexo = itemView.findViewById(R.id.tvSexo);
            tvEdad = itemView.findViewById(R.id.tvEdad);
            tvColor1 = itemView.findViewById(R.id.tvColor1);
            tvColor2 = itemView.findViewById(R.id.tvColor2);
            tvRaza = itemView.findViewById(R.id.tvRaza);
            tvFecha = itemView.findViewById(R.id.tvFecha);
        }
    }
}
