package com.example.zootecbc;

import static com.example.zootecbc.R.color.color_actionbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivityAdmin extends AppCompatActivity {

    private EditText etEmail;
    private EditText etPassword;
    private Button btnLogin;
    Button btn_Signup;
    Button btn_Regresar;
    private Button mButtonResetPassword;

    private String email="";
    private String password="";
    private String area="";

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_admin);

        getSupportActionBar().setBackgroundDrawable(new
                ColorDrawable(getResources().getColor(color_actionbar)));

        this.setTitle("Inicio de sesion administrador");

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        etEmail = (EditText) findViewById(R.id.etEmail);
        etPassword = (EditText) findViewById(R.id.etPassword);
        btnLogin = (Button) findViewById(R.id.btn_btnLogin);
        btn_Signup = (Button) findViewById(R.id.btn_Signup);
        btn_Regresar = (Button) findViewById(R.id.btn_regresar2);
        mButtonResetPassword = (Button) findViewById(R.id.btnSendToResetPassword);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email=etEmail.getText().toString();
                password=etPassword.getText().toString();

                if (!email.isEmpty() && !password.isEmpty()){
                    loginUser();
                }
                else{
                    Toast.makeText(MainActivityAdmin.this,
                            "Complete los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_Regresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivityAdmin.this,
                        MainActivitySelect.class));
            }
        });

        mButtonResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivityAdmin.this,
                        ResetPasswordActivity.class));
            }
        });

        btn_Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent e = new Intent(MainActivityAdmin.this,
                        SignupActivity.class);
                startActivity(e);
            }
        });
    }

    private void loginUser(){
        mAuth.signInWithEmailAndPassword(email,password).
                addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            startActivity(new Intent(MainActivityAdmin.this,
                                    menu_captura_admin.class));
                            finish();
                        }
                        else{
                            Toast.makeText(MainActivityAdmin.this,
                                    "No se pudo iniciar sesion compruebe los datos",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}