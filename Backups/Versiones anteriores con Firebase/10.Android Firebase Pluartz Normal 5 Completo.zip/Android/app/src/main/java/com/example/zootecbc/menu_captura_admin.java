package com.example.zootecbc;

import static com.example.zootecbc.R.color.color_actionbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class menu_captura_admin extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    private TextView mtextViewName;
    //private TextView mtextViewEmail;
    private TextView mtextViewArea;
    private TextView mtextViewPuesto;

    Button subir;
    Button editar;
    ImageButton btn_Signup;

    private Button mButtonSignOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_captura_admin);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(color_actionbar)));
        this.setTitle("Menu principal admin");

        subir = (Button) findViewById(R.id.btn_nueva_captura);
        editar = (Button) findViewById(R.id.btn_editar_captura);
        btn_Signup = (ImageButton) findViewById(R.id.btn_Signup);

        mtextViewName = (TextView) findViewById(R.id.textViewName);
        //mtextViewEmail=(TextView) findViewById(R.id.textViewEmail);
        mtextViewArea = (TextView) findViewById(R.id.textViewArea);
        mtextViewPuesto = (TextView) findViewById(R.id.textViewPuesto);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        mButtonSignOut = (Button) findViewById(R.id.btnSignout);

        subir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CreatePetFragment fm = new CreatePetFragment();
                fm.show(getSupportFragmentManager(), "Navegar a fragment");
            }
        });

        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent e = new Intent(menu_captura_admin.this, menu_animales.class);
                startActivity(e);
            }
        });

        mButtonSignOut.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mAuth.signOut();
                        startActivity(new Intent(menu_captura_admin.
                                this, MainActivity.class));
                        finish();
                    }
                });
        getUserInfo();

        btn_Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent e = new Intent(menu_captura_admin.this,
                        SignupActivity.class);
                startActivity(e);
            }
        });
    }

    private void getUserInfo() {
        String id_usuario = mAuth.getCurrentUser().getUid();
        mDatabase.child("Usuarios").child(id_usuario).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String username = snapshot.child("username").getValue().toString();
                    //String email = snapshot.child("email").getValue().toString();
                    String area = snapshot.child("area").getValue().toString();
                    String puesto = snapshot.child("puesto").getValue().toString();

                    mtextViewName.setText(username);
                    //mtextViewEmail.setText(email);
                    mtextViewArea.setText(area);
                    mtextViewPuesto.setText(puesto);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
/*
    private void UserButton(View view) {
        String id_usuario = mAuth.getCurrentUser().getUid();
        mDatabase.child("Usuarios").child(id_usuario).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String puesto = snapshot.child("puesto").getValue().toString();
                    if (puesto == "SuperAdmin"){
                        btn_Signup.setVisibility(View.VISIBLE);
                    }
                    else{
                        btn_Signup.setVisibility(View.INVISIBLE);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }*/
}