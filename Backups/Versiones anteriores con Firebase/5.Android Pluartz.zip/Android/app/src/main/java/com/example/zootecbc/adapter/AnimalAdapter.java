package com.example.zootecbc.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.zootecbc.R;
import com.example.zootecbc.model.Animal;
import com.firebase.ui.firestore.FirestoreRecyclerAdapter;
import com.firebase.ui.firestore.FirestoreRecyclerOptions;

public class AnimalAdapter extends FirestoreRecyclerAdapter <Animal, AnimalAdapter.ViewHolder>{

    /**
     * Create a new RecyclerView adapter that listens to a Firestore Query.  See {@link
     * FirestoreRecyclerOptions} for configuration options.
     *
     * @param options
     */
    public AnimalAdapter(@NonNull FirestoreRecyclerOptions<Animal> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull ViewHolder holder, int position, @NonNull Animal model) {
        holder.area.setText(model.getArea());
        holder.especie.setText(model.getEspecie());
        holder.raza.setText(model.getRaza());
        holder.tamaño.setText(model.getTamaño());
        holder.sexo.setText(model.getSexo());
        holder.edad.setText(model.getEdad());
        holder.color1.setText(model.getColor1());
        holder.color2.setText(model.getColor2());
        holder.fecha.setText(String.valueOf(model.getFecha()));
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_animal_single, parent, false);
        return new ViewHolder(v);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView area, especie, raza, tamaño, edad, sexo, color1, color2, fecha;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            area = itemView.findViewById(R.id.Area);
            especie = itemView.findViewById(R.id.Especie);
            tamaño = itemView.findViewById(R.id.Tamaño);
            sexo = itemView.findViewById(R.id.Sexo);
            edad = itemView.findViewById(R.id.Edad);
            color1 = itemView.findViewById(R.id.Color1);
            color2 = itemView.findViewById(R.id.Color2);
            raza = itemView.findViewById(R.id.Raza);
            fecha = itemView.findViewById(R.id.Fecha);
        }
    }
}
