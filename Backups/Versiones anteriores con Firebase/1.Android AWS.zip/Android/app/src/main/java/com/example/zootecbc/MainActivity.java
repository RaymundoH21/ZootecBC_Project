package com.example.zootecbc;

import static com.example.zootecbc.R.color.color_actionbar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    AmplifyCognito amplifyCognito;

    Button signin;
    Button signup;

    EditText etusername;
    EditText etpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        amplifyCognito = new AmplifyCognito(getApplicationContext());

        signin=(Button) findViewById(R.id.btnSignIn);
        signup=(Button) findViewById(R.id.btn_signup);

        etusername=(EditText) findViewById(R.id.etUsername);
        etpassword=(EditText) findViewById(R.id.etPassword);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(color_actionbar)));

        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = etusername.getText().toString();
                String password = etpassword.getText().toString();

                amplifyCognito.signIn(username, password);
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent e = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(e);
            }
        });
    }
}