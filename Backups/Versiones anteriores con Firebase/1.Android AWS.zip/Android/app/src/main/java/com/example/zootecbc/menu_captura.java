package com.example.zootecbc;

import static com.example.zootecbc.R.color.color_actionbar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class menu_captura extends AppCompatActivity {

    AmplifyCognito amplifyCognito;

    TextView tvusername;

    Button subir;
    Button editar;
    Button btnsignout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_captura);

        tvusername=(TextView) findViewById(R.id.tvUsername);
        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        tvusername.setText("Bienvenido " + username);

        amplifyCognito = new AmplifyCognito(getApplicationContext());

        subir=(Button) findViewById(R.id.btn_nueva_captura);
        editar=(Button) findViewById(R.id.btn_editar_captura);
        btnsignout=(Button) findViewById(R.id.btnSignout);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(color_actionbar)));

        subir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(menu_captura.this, nueva_captura.class);
                startActivity(i);
            }
        });

        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent e = new Intent(menu_captura.this, menu_animales.class);
                startActivity(e);
            }
        });

        btnsignout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                amplifyCognito.logOut();
            }
        });
    }
}